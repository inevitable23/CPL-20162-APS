function loadMapScenario() {
                var map = new Microsoft.Maps.Map(document.getElementById('myMap'), {
                    credentials: "LaipUfshsMLolLAZr0sq~FDO1x20H4dyJ5APEQeI60w~Amnhlp-hS9x0bwRndSsIHyqE8Nfem8tHvnFl49T9FPSDpuECWnLynsspgCwAjNfm",
                });

                navigator.geolocation.watchPosition(UsersLocationUpdated);

                function UsersLocationUpdated(position){
                  var myloc = new Microsoft.Maps.Location(
                      position.coords.latitude,
                      position.coords.longitude);

                      Microsoft.Maps.loadModule('Microsoft.Maps.Directions', function () {
                            var directionsManager = new Microsoft.Maps.Directions.DirectionsManager(map);
                            // Set Route Mode to walking
                            directionsManager.setRequestOptions({ routeMode: Microsoft.Maps.Directions.RouteMode.walking });
                            var waypoint1 = new Microsoft.Maps.Directions.Waypoint({ address: '내 위치', location: myloc });
                            var waypoint2 = new Microsoft.Maps.Directions.Waypoint({ address: '환자 위치', location: new Microsoft.Maps.Location(35.892066,128.610738)  });
                            directionsManager.addWaypoint(waypoint1);
                            directionsManager.addWaypoint(waypoint2);
                            // Set the element in which the itinerary will be rendered
                            directionsManager.setRenderOptions({ itineraryContainer: document.getElementById('printoutPanel') });
                            directionsManager.calculateDirections();
                        });
                }


}
