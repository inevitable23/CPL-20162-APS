var socketio = require( 'socket.io' );

var rooms = [];

var io;

var functions = {
  connect : function( server ){
    io = socketio( server );
    io.on('connection', function(socket){
      console.log('User connected');

        //io.emit("connectSuccess",{data:"success"});

        socket.on('disconnect', function(){
          console.log('user disconnected');
        });
      //방만들때
        socket.on('joinroom', function( data ){
           socket.join(data.room);
            console.log("joinroom data", data.room);
            socket.room = data.room;
        });


        //방에서 나갈때
        socket.on('exitroom', function(data) {
          var room_id = data.room;
          delete rooms[socket.room];
          console.log("exitroom",rooms);
        });


        //from 119 to walker
        socket.on('from119addr', function(data){
            console.log( "from119addr",data );
            //io.emit("119addrupdate", { data : data.addAddr });
            io.in(socket.room).emit("119addrupdate",{ data : data});
            io.emit("fromServer2", { data : data.addAddr });
        });

        socket.on('from119msg', function(data){
            console.log( "from119msg",data );
            io.in(socket.room).emit("119addmsg",{ data : data});
            //io.emit("119addmsg",{ data : data});
            //io.emit("119addmsg",{ data : data});
            io.emit("fromServer3", { data : data.addMsg });
        });


    });
  },

  toAndroid : function (){
    console.log("sendAndroid");
    io.emit("fromServer1", { data: "occur" });
  }


};

module.exports = functions;
