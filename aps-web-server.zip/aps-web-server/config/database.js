module.exports = {
    'database': 'mongodb://localhost/aps',
    'secret': 'itssecret'
}
